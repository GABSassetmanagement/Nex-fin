const assert = require('node:assert/strict');
const {calculate,products}=require('./dist/assets/finance.js');
assert.equal(calculate(500000,6,'suremoney').total,650000);
assert.ok(Math.abs(calculate(500000,6,'suremoney').monthly-108333.33333333333)<.001);
assert.equal(calculate(100000,12,'women-empowerment').interest,48000);
assert.equal(calculate(1000000,3,'car-for-cash').interest,360000);
assert.equal(calculate(100000,3,'proof-of-funds').total,115000);
assert.equal(calculate(100000,4,'proof-of-funds'),null);
assert.equal(calculate(100000,19,'suremoney'),null);
assert.equal(calculate(-100,6,'suremoney'),null);
assert.equal(calculate(NaN,6,'suremoney'),null);
assert.equal(calculate(100000,6,'unrecognised'),null);
for(const [id,p] of Object.entries(products)){
 assert.ok(calculate(50000,p.min,id));
 assert.ok(calculate(50000,p.max,id));
 assert.equal(calculate(50000,p.min-1,id),null);
 assert.equal(calculate(50000,p.max+1,id),null);
}
console.log('Calculator: formula, boundaries, invalid amounts, all products passed.');
