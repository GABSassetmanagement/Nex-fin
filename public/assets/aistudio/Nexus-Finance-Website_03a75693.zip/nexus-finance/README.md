# Nexus Finance — Sight-inspired website

18 static pages with locally hosted assets and GSAP 3.13.0. Build with `python build.py`. Publish the `dist` directory. No framework or runtime dependency installation is required.

## Pages and interactions

- Home, five loan detail pages, product directory, company and leadership, loan calculator, contact, careers, four insight articles, insight directory, legal information, site map.
- Hero scroll rotation, cursor-following card lighting and tilt, image cutaway hover, scroll-linked vision text, pinned process cards, image parallax, reveal transitions, quote carousel, accessible navigation and native FAQ disclosures.
- All motion respects prefers-reduced-motion. A footer toggle pauses motion.
- Loan estimator uses the source site's flat monthly interest formula. Source rules: Nexus Credit 5%, 3–12 months; Suremoney 5%, 3–18 months; Women Empowerment 4%, 1–12 months; Car for Cash 12%, 3–12 months; Proof of Funds 5%, 1–3 months.
- Contact CTAs offer the verified telephone and WhatsApp destinations. No application submissions or personal data collection occurs on this site.

## Source and content

User-authorized source: https://gabscooperative.com/ and its product, company, calculator, contact, leadership and insight pages. Research snapshot is in `content/source.json`. Company/product brand references are changed to Nexus. Product descriptions, benefits, figures, vision and mission are retained. The supplied Nexus PNG logos are used unchanged.

Visual reference: https://sight-banking.webflow.io/ . Motion references: Winden, Payard and Tuyo, plus the supplied screenshots. Original implementation; no third-party page assets or fonts were copied.

## Before public launch

1. Supply licensed Helvetica Now WOFF2 files. The stylesheet requests Helvetica Now locally, then Helvetica/Arial/sans-serif. No unlicensed font files are bundled.
2. Confirm the Nexus application URL and email domain. Current actions open telephone/WhatsApp support rather than the previous branded portal.
3. Approve final legal terms/privacy text. The source terms were explicitly draft with unresolved placeholders. The legal page is an honest holding page, not an invented approved policy.
4. Resolve Suremoney's 24-month product wording versus the 18-month limit in the published calculator. The site retains the product claim and makes the calculator limit clear.
5. Confirm testimonial attribution: home and about pages in the source reverse the two names. This build uses the homepage attribution. The adjacent generated photo is labeled illustrative.
6. Confirm current career openings. Existing listed roles are retained as enquiry items because the source has no functioning application details.

No claims about Nexus deposit-taking, cards, wallets, licenses or banking-app availability have been added. Generated art is decorative, not a representation of a live banking product or real customer portrait.

## Assets

The two bespoke bitmap assets were created with the built-in image generation tool and optimized to WebP for this site:

- `dist/assets/nexus-sculpture.webp`: exact supplied Nexus mark interpreted as a sapphire-blue and emerald-glass 3D sculpture, beveled metal contours, four-point star center, studio lighting, navy background, no text or payment-card claims.
- `dist/assets/entrepreneur.webp`: original editorial image of a Nigerian female fashion entrepreneur in a sunlit Abuja studio, cobalt blouse, emerald fabric, natural skin detail, candid magazine composition, no logos or text.

Final prompts: create a premium 3:2 campaign render using the supplied Nexus logomark as its structural reference, blue upper-left and emerald lower-right, thick polished glass/metal sculpture, smooth bevels, luminous star-shaped center, subtle glass ribbon, royal-blue studio, raytraced light, no text, numbers, cards, coins or stock symbols. Create an original portrait 4:5 editorial photograph of a confident Nigerian fashion entrepreneur selecting fabric in a refined Abuja studio, natural braids, cobalt shirt, emerald textiles, oak worktable, tall windows, warm natural afternoon light, 35mm composition, authentic texture, no text, logos, signs or watermark.

## Validation

- `python validate.py`: checks all 18 pages for local links/assets/anchors, unique IDs, one H1, image alt attributes, and old visible branding.
- `node verify.cjs`: checks flat-rate examples, invalid amounts, product minimum/maximum periods, and all five product rules.
- `node --check dist/assets/site.js` and `node --check dist/assets/finance.js`.
- Browser review: desktop hero/product grid/calculator, responsive iframe widths 320, 390, 768 and 1024, mobile navigation, calculator product switching, FAQ expansion. No site-origin JavaScript errors observed; browser-extension metadata errors excluded. Phone/tablet layouts showed no horizontal document overflow.

This is a presentation and enquiry website. It does not implement a lending backend, credit decisions, account creation, newsletter delivery, or loan disbursement.
