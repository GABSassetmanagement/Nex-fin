from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
from collections import Counter
import json
root=Path('dist');errors=[]
class Document(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.assets=[];self.h1=0;self.text=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if tag=='h1':self.h1+=1
  if tag=='a' and a.get('href'):self.links.append(a['href'])
  if tag in ['img','script'] and a.get('src'):self.assets.append(a['src'])
  if tag=='img' and 'alt' not in a:errors.append('Image missing alt')
 def handle_data(self,data):self.text.append(data)
pages={}
for path in root.rglob('index.html'):
 d=Document();d.feed(path.read_text());pages[path]=d
 if d.h1!=1:errors.append(f'{path}: {d.h1} H1 elements')
 if any(n>1 for n in Counter(d.ids).values()):errors.append(f'{path}: duplicate IDs')
 if 'gabs' in ''.join(d.text).lower():errors.append(f'{path}: old brand visible')
for path,d in pages.items():
 for ref in d.links+d.assets:
  u=urlsplit(ref)
  if u.scheme or u.netloc:continue
  target=(root/unquote(u.path).lstrip('/')) if u.path.startswith('/') else (path.parent/unquote(u.path))
  if not u.path:target=path
  if target.is_dir():target=target/'index.html'
  if not target.exists():errors.append(f'{path}: broken {ref}')
  if u.fragment and target in pages and u.fragment not in pages[target].ids:errors.append(f'{path}: missing anchor {ref}')
assert not errors,'\n'.join(errors)
print(f'Validated {len(pages)} pages: local links, assets, anchors, unique IDs, H1, image alt text, and Nexus branding.')
