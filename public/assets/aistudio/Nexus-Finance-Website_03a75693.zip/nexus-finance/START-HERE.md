# Nexus Finance website export

The complete editable website is included. No paid hosting platform or Node package installation is required to serve it.

## Preview locally

Extract the ZIP, open a terminal in the nexus-finance folder, and run:

    python3 -m http.server 8000 --directory dist

Open http://localhost:8000 in your browser. Use a local server rather than double-clicking index.html: page links and asset URLs start at the website root.

## Deploy to your hosting provider

Upload the CONTENTS of dist/ to your domain's web root (for example public_html), or set dist as the publish directory on a static hosting provider. Keep the folder structure intact and enable index.html as the directory index. Serve this build at the domain root, not inside a URL subfolder. HTTPS is recommended.

## Edit and rebuild

The existing dist/ folder is ready to host. To regenerate HTML after editing build.py or content/source.json, run python3 build.py. CSS, JavaScript, images and vendor scripts are in dist/assets/. Preserve these assets when rebuilding.

## Checks

    python3 validate.py
    node verify.cjs

See README.md for design details, functionality and outstanding launch items, including the licensed Helvetica Now fonts, Nexus contact/application destinations, final legal text and product-term confirmation. This export contains the presentation/enquiry site and calculator, not a lending backend.
